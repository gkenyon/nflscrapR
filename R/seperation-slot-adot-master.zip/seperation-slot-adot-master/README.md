# seperation-slot-adot
What drives seperation? aDOT, slot target percentage? 
